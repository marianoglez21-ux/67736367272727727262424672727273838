package com.isla.perdida

import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class Choice(val label: String, val next: String, val effect: () -> String = { "" })

class MainActivity : AppCompatActivity() {
    var hp = 100; var food = 70; var water = 70
    var steps = 0; var signalStep = -1
    val items = mutableSetOf<String>()
    lateinit var status: TextView
    lateinit var story: TextView
    lateinit var box: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        show("beach", "")
    }

    fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0B1D26"))
            setPadding(40, 60, 40, 40)
        }
        status = TextView(this).apply { setTextColor(Color.parseColor("#7FD6C2")); textSize = 14f }
        story = TextView(this).apply { setTextColor(Color.WHITE); textSize = 18f; setPadding(0, 30, 0, 30) }
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(story); addView(box)
        }
        root.addView(status)
        root.addView(ScrollView(this).apply { addView(inner) })
        setContentView(root)
    }

    fun reset() {
        hp = 100; food = 70; water = 70; steps = 0; signalStep = -1; items.clear()
    }

    fun tick() {
        food = (food - 6).coerceAtLeast(0)
        water = (water - 8).coerceAtLeast(0)
        if (food == 0 || water == 0) hp -= 20
        steps++
    }

    fun scene(id: String): Pair<String, List<Choice>> = when (id) {
        "beach" -> Pair(
            "Tu excursión en barco salió mal: una tormenta, y ahora estás con tus amigos en una playa desconocida. Sin señal, sin barco.",
            buildList {
                add(Choice("Adentrarse en la selva", "jungle"))
                add(Choice("Buscar un río", "river"))
                add(Choice("Caminar por la orilla", "wreck"))
                add(Choice("Juntar leña", "beach") { items.add("leña"); "Juntas un buen montón de leña." })
                if ("leña" in items && "encendedor" in items && signalStep < 0)
                    add(Choice("Encender fogata de señal", "beach") {
                        signalStep = steps; "La fogata arde alto. Alguien podría verla en unas horas..."
                    })
                add(Choice("Descansar", "beach") { hp = (hp + 10).coerceAtMost(100); "Recuperas algo de fuerza." })
            }
        )
        "jungle" -> Pair(
            "La selva es densa y húmeda. Se oyen animales entre las hojas.",
            listOf(
                Choice("Recoger cocos", "jungle") { food = (food + 25).coerceAtMost(100); water = (water + 10).coerceAtMost(100); "Comes cocos. Mejor." },
                Choice("Seguir un sendero hacia una cueva", "cave"),
                Choice("Volver a la playa", "beach")
            )
        )
        "river" -> Pair(
            "Encuentras un río de agua clara que baja hacia el mar.",
            buildList {
                add(Choice("Beber agua", "river") { water = 100; "Bebes hasta saciarte." })
                if ("cuerda" in items)
                    add(Choice("Pescar con la cuerda", "river") { food = (food + 30).coerceAtMost(100); "Pescas un pez grande." })
                add(Choice("Volver a la playa", "beach"))
            }
        )
        "wreck" -> Pair(
            "En la orilla norte hay restos del barco entre las rocas.",
            buildList {
                if ("cuerda" !in items)
                    add(Choice("Revisar los restos", "wreck") { items.add("cuerda"); hp -= 5; "Te cortas un poco, pero consigues una cuerda." })
                add(Choice("Volver a la playa", "beach"))
            }
        )
        else -> Pair(
            "La cueva está oscura y huele a humedad.",
            listOf(
                Choice("Entrar y buscar", "cave") {
                    if ("encendedor" in items) "No queda nada más útil."
                    else if (Random.nextBoolean()) { items.add("encendedor"); "¡Encuentras un encendedor en una mochila vieja!" }
                    else { hp -= 15; "Murciélagos te asustan y te caes. -15 salud." }
                },
                Choice("Salir a la selva", "jungle")
            )
        )
    }

    fun show(id: String, msg: String) {
        val (text, choices) = scene(id)
        status.text = "Día ${1 + steps / 3}   Salud $hp   Comida $food   Agua $water\nObjetos: ${if (items.isEmpty()) "ninguno" else items.joinToString()}"
        story.text = (if (msg.isNotEmpty()) msg + "\n\n" else "") + text
        box.removeAllViews()
        for (c in choices) addButton(c.label) { go(c) }
    }

    fun go(c: Choice) {
        val msg = c.effect()
        tick()
        when {
            hp <= 0 -> end("Las fuerzas te abandonan en la isla...\n\nFIN")
            signalStep >= 0 && steps >= signalStep + 6 ->
                end("Un helicóptero de rescate ve tu fogata. ¡Se acabó la pesadilla, los rescatan!\n\nFIN")
            else -> show(c.next, msg)
        }
    }

    fun end(text: String) {
        story.text = text
        box.removeAllViews()
        addButton("Jugar de nuevo") { reset(); show("beach", "") }
    }

    fun addButton(label: String, onClick: () -> Unit) {
        val b = Button(this).apply { text = label; setOnClickListener { onClick() } }
        box.addView(b)
    }
}
